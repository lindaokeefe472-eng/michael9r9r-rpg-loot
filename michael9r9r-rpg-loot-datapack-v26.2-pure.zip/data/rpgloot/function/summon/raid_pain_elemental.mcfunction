tellraw @a {"text":"You hear demonic rambling draw closer...","color":"dark_red"}

bossbar add rpgloot.painelemental {"text":"Pain Elemental","color":"red"}
bossbar set rpgloot.painelemental color red
bossbar set rpgloot.painelemental max 400


summon ghast ~ ~10 ~ {CustomName:"\"§cPain Elemental\"",CustomNameVisible:1,DeathLootTable:"rpgloot:pain_elemental_loot",ActiveEffects:[{name:"minecraft:water_breathing",amplifier:0,duration:999999},{name:"minecraft:regeneration",amplifier:0,duration:999999},{name:"minecraft:fire_resistance",amplifier:1,duration:999999},{name:"minecraft:resistance",amplifier:0,duration:999999},{name:"minecraft:jump_boost",amplifier:3,duration:999999}],Attributes:[{name:"minecraft:max_health",base:400.0},{name:"minecraft:movement_speed",base:1.40f},{name:"minecraft:follow_range",base:170.0f},{name:"minecraft:knockback_resistance",base:0.50f},{name:"minecraft:attack_knockback",base:4.0f},{name:"minecraft:attack_damage",base:9.0f}],Silent:0,Glowing:0,Health:400.0f,Tags:["rpgloot.boss","rpgloot.ghast",rpgloot.painelemental]}